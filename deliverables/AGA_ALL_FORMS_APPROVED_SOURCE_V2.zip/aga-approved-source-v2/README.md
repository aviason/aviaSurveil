# AGA Approved Source V2

This package is an immutable technical import of the project-provided Aviation-approved AGA source.
It is operationally governed by the source classification, not by a second human approval or publication step.

Optional risk, regulatory, and currentness enrichment is explicitly not approved and is never required for import.
The complete question inventory is available for Department Manager subset selection; import does not preselect it for an Audit.
